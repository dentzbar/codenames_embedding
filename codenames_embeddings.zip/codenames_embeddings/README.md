# 🕵️‍♂️ Codenames Game via Embedding-Based Encoder-Decoder

This project implements the core logic behind the **Codenames** game using modern NLP embedding models. It uses an **encoder-decoder framework**, where the encoder maps a clue to the most semantically related words on the board — powered by embeddings from **GloVe**, **RoBERTa**, and **OpenAI**.

---

## 🚀 Getting Started

Follow the steps below to set up your environment and run the demo.

---

### 1. 📦 Create a Virtual Environment & Install Requirements

```bash
python -m venv venv
source venv/bin/activate  # On Windows use: venv\Scripts\activate
pip install -r requirements.txt
```

---

### 2. 📥 Download GloVe Embeddings

Download the GloVe vectors and place them into the expected directory:

```bash
wget http://nlp.stanford.edu/data/glove.6B.zip
unzip glove.6B.zip -d codenames_embeddings/data/glove/
rm glove.6B.zip
```

Make sure this file exists afterwards:

```bash
codenames_embeddings/data/glove/glove.6B.300d.txt
```

---

### 3. 🔑 Set OpenAI API Key

Create a `.env` file at:

```
codenames_embeddings/embedding_models/.env
```

Add your API key like this:

```dotenv
OPENAI_API_KEY=<API_KEY>
```

> 🔁 Alternatively, set it as an environment variable:
> ```bash
> export OPENAI_API_KEY=sk-...
> ```

---

### 4. ▶️ Run the Demo

Use this command from the project root:

```bash
PYTHONPATH=. python codenames_embeddings/examples/demo_embed.py
```

You’ll see sample embeddings and top-k similar words for each model.

---

## 🧠 What’s Inside?

This project includes:

| File/Folder                              | Purpose |
|------------------------------------------|---------|
| `embedding_models/base.py`               | Abstract base class for all models |
| `embedding_models/glove_model.py`        | GloVe embeddings from pretrained vectors |
| `embedding_models/roberta_model.py`      | RoBERTa embeddings via HuggingFace |
| `embedding_models/openai_model.py`       | OpenAI API for embedding generation |
| `utils/similarity.py`                    | Cosine similarity + top-k lookup |
| `examples/demo_embed.py`                 | Test and visualize embeddings |
| `data/glove/glove.6B.300d.txt`           | Downloaded GloVe vectors |

---

## 🧩 How It Works

- The **decoder** (to be implemented) gives a one-word clue.
- The **encoder** finds the `top-k` board words most related to the clue.
- All models use a shared interface (`EmbeddingModel`) to make extending easy.

---

## 🔧 Extend the Code

- Add your own decoder logic to find the optimal clue for given target words.
- Replace or expand the vocabulary for the Codenames board.
- Add support for sentence context or few-shot learning.

---

## 📜 License

MIT License

---

## 🤝 Contributing

Pull requests are welcome! Please open an issue first to discuss changes or ideas.

---

## 🎯 Goals

This project is intended for experimentation with:
- Embedding similarity
- Clue generation for multi-target reasoning
- Encoder-decoder design in games and NLP

---

Made with ❤️ for language, logic, and learning.
