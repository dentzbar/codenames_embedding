from embedding_models.base import EmbeddingModel
import openai
import numpy as np
from typing import Union, List
from dotenv import load_dotenv
import os

class OpenAIEmbeddingModel(EmbeddingModel):
    def __init__(self, model="text-embedding-ada-002", api_key=None):
        self.model = model
        self.load_api_key(api_key)
        self.embeddings = {}

    def load_api_key(self, api_key: str = None):
        if api_key:
            openai.api_key = api_key
            return
        
        load_dotenv()
        openai.api_key = os.getenv("OPENAI_API_KEY")
        if openai.api_key is None:
            raise ValueError(f"Failed to load API key")

    def embed(self, words: Union[str, List[str]]) -> Union[np.ndarray, List[np.ndarray]]:
        if isinstance(words, str):
            return self._get_embedding(words)
        return [self._get_embedding(w) for w in words]

    def _get_embedding(self, word: str) -> np.ndarray:
        response = openai.Embedding.create(model=self.model, input=word)
        vector = np.array(response["data"][0]["embedding"], dtype=np.float32)
        self.embeddings[word] = vector
        return vector

    def get_all_embeddings(self) -> dict:
        return self.embeddings